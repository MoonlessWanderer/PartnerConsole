"""Explicit, interactive maintenance command. Never called by application startup."""
import argparse
import getpass
import re

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

from app.core.database import SessionLocal
from app.core.security import hash_password
from app.models import AdminUser

_USERNAME = re.compile(r"[A-Za-z][A-Za-z0-9._-]{0,63}")


def validate_admin_username(username: str) -> str:
    username = username.strip()
    if _USERNAME.fullmatch(username) is None:
        raise ValueError("Username must start with a letter and use only letters, numbers, dots, underscores, or hyphens")
    return username


def rename_admin(db, admin_id: int, username: str) -> str:
    """Rename one admin. Existing JWTs stay valid because they carry the user id."""
    username = validate_admin_username(username)
    admin = db.get(AdminUser, admin_id)
    if admin is None:
        raise ValueError("Admin not found; this command does not create accounts or run migrations")
    previous = admin.username
    if username == previous:
        return previous
    taken = db.scalar(select(AdminUser.id).where(AdminUser.username == username))
    if taken is not None:
        raise ValueError("That username is already used")
    admin.username = username
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise ValueError("That username is already used") from None
    return previous


def set_password(db, username: str, password: str) -> None:
    if not 12 <= len(password) <= 200 or password == "admin12345" or password == username:
        raise ValueError("Choose a non-default password of 12–200 characters")
    admin = db.scalar(select(AdminUser).where(AdminUser.username == username))
    if admin is None:
        raise ValueError("Admin not found; this command does not create accounts or run migrations")
    admin.password_hash = hash_password(password)
    db.commit()


def main():
    parser = argparse.ArgumentParser(description="Reset an existing administrator password interactively")
    parser.add_argument("username")
    args = parser.parse_args()
    password = getpass.getpass("New admin password: ")
    if password != getpass.getpass("Repeat password: "):
        raise SystemExit("Passwords do not match")
    try:
        with SessionLocal() as db:
            set_password(db, args.username, password)
    except ValueError as exc:
        raise SystemExit(str(exc)) from None
    print("Password updated. Rotate ADMIN_JWT_SECRET too if existing sessions must be invalidated.")


if __name__ == "__main__":
    main()

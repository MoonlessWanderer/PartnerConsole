#!/usr/bin/env bash
# Change one existing admin. Password hashing is the application's own function.
# A new password does not revoke JWTs: sessions carry the admin id, and the
# existing maintenance command says to rotate ADMIN_JWT_SECRET for that.

pp_credentials_python() {
  local python="$PP_ROOT/backend/.venv/bin/python"
  [[ -x "$python" ]] || python=python3
  (cd "$PP_ROOT/backend" && "$python" "$@")
}

pp_credentials_list() {
  pp_credentials_python - <<'PY'
from sqlalchemy import select
from app.core.database import SessionLocal
from app.models import AdminUser
with SessionLocal() as db:
    rows = db.scalars(select(AdminUser).order_by(AdminUser.id)).all()
    if not rows:
        raise SystemExit("No administrator exists.")
    for row in rows:
        print(f"{row.id} {row.username}")
PY
}

pp_credentials_rename() {
  local admin_id="$1" username="$2" previous
  previous="$(PP_ADMIN_ID="$admin_id" PP_ADMIN_USERNAME="$username" pp_credentials_python - <<'PY'
import os
from app.core.database import SessionLocal
from app.reset_admin_password import rename_admin
with SessionLocal() as db:
    print(rename_admin(db, int(os.environ["PP_ADMIN_ID"]), os.environ["PP_ADMIN_USERNAME"]))
PY
)"
  if [[ -f "$PP_ROOT/config/api.env" ]]; then
    PP_ENV_FILE="$PP_ROOT/config/api.env" PP_ENV_OLD="$previous" PP_ENV_NEW="$username" python3 - <<'PY'
import os
from pathlib import Path
path = Path(os.environ["PP_ENV_FILE"])
old, new = os.environ["PP_ENV_OLD"], os.environ["PP_ENV_NEW"]
info = path.stat()
lines = []
for line in path.read_text(encoding="utf-8").splitlines():
    if line == f"ADMIN_USERNAME={old}":
        line = f"ADMIN_USERNAME={new}"
    lines.append(line)
path.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
os.chmod(path, info.st_mode & 0o777)
os.chown(path, info.st_uid, info.st_gid)
PY
  fi
  echo "Administrator ${admin_id} is now ${username}. Existing sessions still use the same account id."
}

pp_credentials_password() {
  local admin_id="$1" username first second
  username="$(PP_ADMIN_ID="$admin_id" pp_credentials_python - <<'PY'
import os
from app.core.database import SessionLocal
from app.models import AdminUser
with SessionLocal() as db:
    admin = db.get(AdminUser, int(os.environ["PP_ADMIN_ID"]))
    if admin is None:
        raise SystemExit("Admin not found")
    print(admin.username)
PY
)"
  echo "This does not sign out existing sessions. ADMIN_JWT_SECRET is not changed."
  read -r -s -p "New password: " first </dev/tty
  printf '\n'
  read -r -s -p "Repeat password: " second </dev/tty
  printf '\n'
  [[ "$first" == "$second" ]] || { unset first second; echo "The passwords do not match." >&2; return 1; }
  printf '%s' "$first" | PP_ADMIN_USERNAME="$username" pp_credentials_python -c '
import os
import sys
from app.core.database import SessionLocal
from app.reset_admin_password import set_password
password = sys.stdin.read()
with SessionLocal() as db:
    set_password(db, os.environ["PP_ADMIN_USERNAME"], password)
'
  unset first second
  echo "Password updated. Existing sessions stay valid until they expire or you rotate ADMIN_JWT_SECRET."
  echo "The previous password can no longer be used to sign in."
}

pp_credentials_menu() {
  local choice admin_id username
  [[ -r /dev/tty ]] || { echo "Admin credentials need a terminal." >&2; return 1; }
  while true; do
    printf '\nAdmin Credentials\n\n  1) Change Admin Username\n  2) Change Admin Password\n  0) Back\n\n'
    read -r -p "Choice: " choice </dev/tty
    case "$choice" in
      1|2)
        pp_credentials_list || return 1
        read -r -p "Admin id: " admin_id </dev/tty
        [[ "$admin_id" =~ ^[0-9]+$ ]] || { echo "Choose an administrator by id." >&2; continue; }
        if [[ "$choice" == "1" ]]; then
          read -r -p "New username: " username </dev/tty
          pp_credentials_rename "$admin_id" "$username" || true
        else
          pp_credentials_password "$admin_id" || true
        fi
        ;;
      0) return 0 ;;
      *) echo "Invalid choice." ;;
    esac
  done
}

if [[ "${PP_CREDENTIALS_LIBRARY:-}" != "1" && "${BASH_SOURCE[0]}" == "$0" ]]; then
  set -euo pipefail
  pp_credentials_menu
fi
